package Aho_Corassick;
import java.util.ArrayList;

public class Tree {

    private ArrayList<State> tree= new ArrayList <>();

    public Tree(){
        tree.add(new State());
    }

    public int get_fail(int state){
        return tree.get(state).getFail_transition();
    }

    public boolean is_final_state(int state){
        return tree.get(state).Is_final();
    }

    private int Add_state(char c,boolean f){
        tree.add(new State(c,f));
        return tree.size()-1;
    }

    private boolean End_of_word(int i, String w){
        return w.length()-1==i;
    }

    public int Get_state_from_char(int state, char c){

        for(Integer i:tree.get(state).getTransitions()){
            if(tree.get(i).getIncoming_char()==c) {
                return i;
            }
        }
        return state;
    }

    private int Add_transition(int state, char c, boolean f){
        int new_state = Add_state(c,f);

        tree.get(state).Add_transition(new_state);
        return new_state;
    }

    public void Add_word(String[] words){
        for(String s:words){
            Add_word(s);
        }
    }

    public void Add_word(String word) {
        int actual_state=0,tmp;
        for (int i = 0; i < word.length(); i++) {
            char c = word.charAt(i);
            tmp=actual_state;
            actual_state = Get_state_from_char(actual_state, c);

            if(tmp==actual_state)
                actual_state = Add_transition(actual_state,c,End_of_word(i,word));

        }
    }

    public void Links_Addition(String[] Searched_words){

        //prefix_actual_state va contenir le début du mot que l'on peut former avec le suffixe
        int i, suffix_state,prefix_actual_state=0,previous_state,prefix_state=0,j=1,from=0;
        char c,prefix_c;
        boolean find=false;

        for(String word:Searched_words) {
            suffix_state =0;
            prefix_actual_state=Get_state_from_char(0,word.charAt(0));
            //on parcours l'ensemble des mots
            //System.out.println("mot actuel: "+word);
            for(i=j;i<word.length();i++){//on parcours les lettres de chaque mots en partant du rang j
                c = word.charAt(i);
                previous_state= suffix_state;
                suffix_state = Get_state_from_char(suffix_state, c);
                prefix_actual_state=Get_state_from_char(prefix_actual_state,word.charAt(j));

                //System.out.println("Lettre cherchée: "+c);
                //System.out.println("Rang j: "+j+" i: "+i);
                //System.out.println("Etat suffixe actuel: "+ suffix_state+" lettre: "+tree.get(suffix_state).getIncoming_char());
                //System.out.println("Etat prefixe actuel: "+ prefix_actual_state+" lettre: "+tree.get(prefix_actual_state).getIncoming_char());

                //est ce que la lettre actuel du mot se retrouve dans un préfixe venant d'un autre mot ?
                if(suffix_state ==previous_state){
                    //la lettre n'a pas entrainé un changement d'état: on a pas bougé dans le graphe
                    i=j;
                    //on va recommancer la boucle en prenant un suffixe plus petit
                }else{
                    /*La lettre a été retrouvé dans un préfixe, donc on va rajouter une transition
                    d'erreur qui évitera de retourner à la racine quand on tombe sur cette lettre
                    et qu'aucune transition ne correspond à la suite du mot recherché.
                    A la place, on ira directement sur le préfixe qui a cette lettre en commun
                     */
                    //System.out.println("On met une transition d'echec de "+prefix_actual_state+" à "+suffix_state);
                    tree.get(prefix_actual_state).Add_fail(suffix_state);
                }
                j++;
                //System.out.println("\n\n");


            }
            j=1;
        }

    }

    public void print_tree(){

            for(Integer i:tree.get(0).getTransitions()){
                System.out.println(i+"-"+tree.get(i).getIncoming_char()+" ("+tree.get(i).Is_final()+")");
                for(Integer j:tree.get(i).getTransitions()) {
                    System.out.println("+\t"+j+"-"+tree.get(j).getIncoming_char()+" ("+tree.get(j).Is_final()+")");
                    for(Integer k:tree.get(j).getTransitions()) {
                        System.out.println("\t-\t" +k+"-"+ tree.get(k).getIncoming_char()+" ("+tree.get(k).Is_final()+")");
                        for (Integer l : tree.get(k).getTransitions()) {
                            System.out.println("\t\t\t\\" +l+"-"+ tree.get(l).getIncoming_char()+" ("+tree.get(l).Is_final()+")");
                            for (Integer m : tree.get(l).getTransitions()) {
                                System.out.println("\t\t\t| " +m+"-"+ tree.get(m).getIncoming_char()+" ("+tree.get(m).Is_final()+")");
                                for (Integer n : tree.get(m).getTransitions()) {
                                    System.out.println("\t\t\t|  " +n+"-"+ tree.get(n).getIncoming_char()+" ("+tree.get(n).Is_final()+")");
                                    for (Integer o : tree.get(n).getTransitions()) {
                                        System.out.println("\t\t\t|   " +o+"-"+ tree.get(o).getIncoming_char()+" ("+tree.get(o).Is_final()+")");
                                        for (Integer p : tree.get(o).getTransitions()) {
                                            System.out.println("\t\t\t|    " +p+"-"+ tree.get(p).getIncoming_char()+" ("+tree.get(p).Is_final()+")");
                                        }
                                        System.out.print("\n");
                                    }
                                }
                            }
                        }
                    }
                }
            }
            System.out.print("\n\n");
    }

    public void print_fail(){
        for(Integer i:tree.get(0).getTransitions()){
            System.out.println(tree.get(i).getFail_transition());
            for(Integer j:tree.get(i).getTransitions()) {
                System.out.println("+\t"+tree.get(j).getFail_transition());
                for(Integer k:tree.get(j).getTransitions()) {
                    System.out.println("\t-\t" + tree.get(k).getFail_transition());
                    for (Integer l : tree.get(k).getTransitions()) {
                        System.out.println("\t\t\t\\" + tree.get(l).getFail_transition());
                        for (Integer m : tree.get(l).getTransitions()) {
                            System.out.println("\t\t\t| " + tree.get(m).getFail_transition());
                            for (Integer n : tree.get(m).getTransitions()) {
                                System.out.println("\t\t\t|  " + tree.get(n).getFail_transition());
                                for (Integer o : tree.get(n).getTransitions()) {
                                    System.out.println("\t\t\t|   " + tree.get(o).getFail_transition());
                                    for (Integer p : tree.get(o).getTransitions()) {
                                        System.out.println("\t\t\t|    " + tree.get(p).getFail_transition());
                                    }
                                    System.out.print("\n");
                                }
                            }
                        }
                    }
                }
            }
        }
        System.out.print("\n\n");
    }
}
