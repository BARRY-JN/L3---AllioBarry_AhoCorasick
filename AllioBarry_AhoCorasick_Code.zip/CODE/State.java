package Aho_Corassick;
import java.util.ArrayList;

public class State {

    private char incoming_char;

    private boolean is_final;
    private ArrayList<Integer> transitions = new ArrayList <>();

    private int fail_transition;

    public int getFail_transition() {
        return fail_transition;
    }

    public ArrayList<Integer> getTransitions() {
        return transitions;
    }

    public char getIncoming_char() {
        return incoming_char;
    }

    public boolean Is_final() {
        return is_final;
    }

    public State(){
        incoming_char='\0';
        is_final=false;
        fail_transition=0;
    }

    public State(char c,boolean f){
        incoming_char=c;
        is_final=f;
        fail_transition=0;
    }

    public void Add_transition(int state){
        transitions.add(state);
    }
    public void Add_fail(int target){fail_transition=target;}


}
