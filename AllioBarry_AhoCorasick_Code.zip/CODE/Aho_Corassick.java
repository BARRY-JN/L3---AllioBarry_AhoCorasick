package Aho_Corassick;
public class Aho_Corassick {

    public static Tree init_search(String[] mots_cles){
        Tree t=new Tree();
        t.Add_word(mots_cles);
        t.print_tree();
        t.Links_Addition(mots_cles);
        t.print_fail();
        return t;
    }

    public static int next_state(Tree t,int state,char c){
        int before=state,tmp=-1;
        state=t.Get_state_from_char(state,c);
        if(before==state){
            tmp=t.get_fail(state);
            state=t.Get_state_from_char(tmp,c);
        }
        return state;
    }
}
