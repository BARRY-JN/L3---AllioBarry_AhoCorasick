import Aho_Corassick.*;

import javax.swing.*;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;

public class AOForm extends JFrame{
    private JTextPane textPane1;
    private JTextPane textPane2;
    private JButton button1;
    private JPanel jpanel1;
    private JProgressBar progressBar1;

    public AOForm(){
        setContentPane(jpanel1);
        pack();
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        button1.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                String tmp,texte="";
                String[] searched_word;
                Tree aho;
                int i=0,j=0,actual_state=0,start=0,end=0,max=0;
                boolean find=false;
                char letter='\n';

                tmp=textPane2.getText();
                searched_word=tmp.split("\\r?\\n");
                aho=Aho_Corassick.init_search(searched_word);

                SimpleAttributeSet noir = new SimpleAttributeSet();
                StyleConstants.setForeground(noir, Color.BLACK);

                textPane1.selectAll();
                textPane1.setCharacterAttributes(noir,true);

                SimpleAttributeSet sas = new SimpleAttributeSet();
                StyleConstants.setForeground(sas, Color.RED);

                max=textPane1.getDocument().getLength();
                try {
                    texte=textPane1.getDocument().getText(0,max);
                } catch (BadLocationException e1) {
                    e1.printStackTrace();
                }


                for(i=0;i<max;i++){
                    letter=texte.charAt(i);
                    if(letter!='\n'&&letter!='\r') {


                        actual_state = Aho_Corassick.next_state(aho, actual_state, letter);
                        if (actual_state != 0 && !find) {
                            start = i;
                            find = true;
                        }
                        if (actual_state == 0) {
                            find = false;
                        }
                        if (aho.is_final_state(actual_state) && find) {
                            end = i;
                            find = false;
                        }
                        if (end > start) {
                            textPane1.setSelectionStart(start);
                            textPane1.setSelectionEnd(end + 1);
                            textPane1.setCharacterAttributes(sas, false);

                        }
                    }
                    if (i % 10 == 0) {
                        progressBar1.setValue((i * 100) / max);
                    }
                }

            }
        });

        setVisible(true);
    }
}
